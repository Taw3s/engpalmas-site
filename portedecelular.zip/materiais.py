materiais = []

for i in range(3):
    material = input('Digite o nome do material:')
    materiais.append(material)

print('Os materiais são:')
print(materiais)
    
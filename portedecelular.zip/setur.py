setup = ["Processador i5", "Placa Gráfica RTX 3060", "RAM 8GB", "SSD 500GB"]
setup[2] = 'RAM 16GB DDR5'
print(setup)